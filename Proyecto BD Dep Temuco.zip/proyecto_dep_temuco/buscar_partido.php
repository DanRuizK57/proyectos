<?php 
include "php/conexionBD.php";
$link=AbrirConexion();
$CadSql="Select a.cod_region,a.des_region from region a;";
$regiones=EjecutarConsulta($CadSql,$link);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Buscar Partido</title>
	

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="row">
		<div class="col-sm-12 text-center" id="encabezado">
			<?php 
			include "php/encabezado.php";
			?>
		</div>
	</div>
	<div class="row">
		</div>
		<div class="col-sm-12 text-center" id="contenido">
			<form action="mostrar_partido.php" method="POST">
				<br>
				<?php 
				include "php/menu.php";
				?>
				<br><br><br><br>
				<div class="col-sm-3"></div>
				<div class="col-sm-6">
					<div class="panel panel-primary">
						<div class="panel-heading">Búsqueda de partido</div>
						<div class="panel-body text-left">
							<div class="col-sm-3">N&uacute;mero Partido</div>
      						<div class="col-sm-9">
      							<input type="search" name="txtNroPartido" id="txtNroPartido" placeholder="Ingrese n° partido" maxlength="6" minlength="1" required="required" size="45">
      						</div>
							<br><br>
							<div class="panel-body text-center">
								<div class="col-sm-3"></div>
								<div class="col-sm-6">
									<input type="submit" name="cmdBuscar" id="cmdBuscar" value="Buscar Cliente" class="btn btn-primary">
								</div>
								<div class="col-sm-3"></div>
							</div>

							<?php 
							
							if(isset($_GET["error"])){
								$error=$_GET["error"];	
								if($error=="si")
								{
									?>
									<div class="row">
										<div class="col-sm-12">
											<span class="error"> 
												El partido ingresado no existe. Intente nuevamente.
											</span>
										</div>
									</div>
									<?php 
								}
							}
							?>

						</div>
					</div>
					<div class="col-sm-3"></div>
				</form>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12" id="pie">
				<div class="clearfix"></div>
    <footer id="footer">
        <div class="wrap">

            <div id="info">
                <h5>Desarrollado con</h5>
                <p>
                    <img src="img/html5.png" alt="Creado con HTML y CSS">
                    <img src="img/php.png" alt="Programado con PHP" height="100px">
                </p>
            </div>
            <div>
                <h5>AUTOR</h5>
                <p>&copy; Daniel Ruiz</p>
                <p>Estudiante de Ingeniería Informática</p>
                <p>Contacto: d.ruiz03@ufromail.cl</p>
                <img src="img/logo_ufro.png" alt="Universidad de la Frontera" height="150px">
            </div>

            

        </div>
    </footer>
			</div>
		</div>
	</body>
	</html>