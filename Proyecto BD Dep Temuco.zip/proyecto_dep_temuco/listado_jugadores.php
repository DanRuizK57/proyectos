<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Listado de Jugadores</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="row">
		<div class="col-sm-12 text-center" id="encabezado">
			<?php 
			include "php/encabezado.php";
			?>
		</div>
	</div>
	<div class="row">
		</div>
		<div class="col-sm-12 text-center" id="contenido">
		<br>
		<?php 
		include "php/menu.php";
		include "php/conexionBD.php";
		$link=AbrirConexion();
		

		$CadSql="Select a.cod_jugador,a.nombre_jugador,a.fecha_nacimiento_jugador,a.dorsal,b.cod_pais,b.des_pais,c.cod_posicion,c.des_posicion,d.fecha_inicio,d.fecha_termino,e.cod_equipo,e.nombre_equipo ";
		$CadSql.=" from jugador a,pais b,posicion c,jugadores_equipo d,equipo e where a.cod_pais=b.cod_pais and a.cod_posicion=c.cod_posicion and d.cod_jugador=a.cod_jugador and d.cod_equipo=e.cod_equipo order by cod_jugador asc;";
		$resultado=EjecutarConsulta($CadSql,$link);
		?>
		<table class="listado" border="1">
			<br><br>
			<tr>
					<th>C&oacute;digo Jugador</th>
					<th>Nombre Jugador</th>
					<th>Fecha de Nacimiento</th>
					<th>Pa&iacute;s</th>
					<th>Posici&oacute;n</th>
					<th>Dorsal</th>
					<th>Equipo</th>
					<th>Inicio Contrato</th>
					<th>T&eacute;rmino Contrato</th>
				</tr>

				<?php
				while($fila=$resultado->fetch_array())
				{
					echo "<tr><td>".$fila["cod_jugador"]."</td>";
					echo "<td>".$fila["nombre_jugador"]."</td>";
					echo "<td>".$fila["fecha_nacimiento_jugador"]."</td>";
					echo "<td>".$fila["des_pais"]."</td>";
					echo "<td>".$fila["des_posicion"]."</td>";
					echo "<td>".$fila["dorsal"]."</td>";
					echo "<td>".$fila["nombre_equipo"]."</td>";
					echo "<td>".$fila["fecha_inicio"]."</td>";
					echo "<td>".$fila["fecha_termino"]."</td></tr>";
				}
				?>
				<tr>
					<td>Total Jugadores</td>
					<td>
						<?php echo $resultado->num_rows;?>	
					</td>
				</tr>
		</table>
		<?php
		CerrarConexion($link);
		?>
		<br><br>
	</div>
</div>
<div class="row">
	<div class="col-sm-12" id="pie">
		<div class="clearfix"></div>
    <footer id="footer">
        <div class="wrap">

            <div id="info">
                <h5>Desarrollado con</h5>
                <p>
                    <img src="img/html5.png" alt="Creado con HTML y CSS">
                    <img src="img/php.png" alt="Programado con PHP" height="100px">
                </p>
            </div>
            <div>
                <h5>AUTOR</h5>
                <p>&copy; Daniel Ruiz</p>
                <p>Estudiante de Ingeniería Informática</p>
                <p>Contacto: d.ruiz03@ufromail.cl</p>
                <img src="img/logo_ufro.png" alt="Universidad de la Frontera" height="150px">
            </div>

            

        </div>
    </footer>
	</div>
</div>
</body>
</html>