<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Guardar Partido</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="row">
		<div class="col-sm-12 text-center" id="encabezado">
			<?php 
			include "php/encabezado.php";
			?>
		</div>
	</div>
	<div class="row">
		</div>
		<div class="col-sm-12 text-center" id="contenido">
		<br>
		<?php 
		include "php/menu.php";
		//if(isset($_POST["txtCodCampeonato"]) && isset($_POST["txtNroPartido"]))
		if(isset($_POST["txtNroPartido"]))
		{	
			include "php/conexionBD.php";
			include "php/validaciones.php";
			$link=AbrirConexion();
			$codCampeonato=$_POST["cboCampeonato"];
			$nroPartido=$_POST["txtNroPartido"];
			$fechaPartido=$_POST["dtFechaPartido"];
			$estadio=$_POST["cboEstadio"];
			$equipoLocal=$_POST["cboEquipoLocal"];
			$equipoVisita=$_POST["cboEquipoVisita"];
			$golesLocal=$_POST["txtGolesLocal"];
			$golesVisita=$_POST["txtGolesVisita"];
			
			$CadSql="insert into partido(cod_campeonato,nro_partido,fecha_partido,cod_estadio,cod_equipo_local,cod_equipo_visita,goles_local,goles_visita) ";
			$CadSql.=" value('".$codCampeonato."','".$nroPartido."','".$fechaPartido."','".$estadio."','";
			$CadSql.=$equipoLocal."','".$equipoVisita."','".$golesLocal."','".$golesVisita."');";
			//echo "<br>".$CadSql;

			if(ExistePartido($nroPartido))
			{
				$mensaje="Este partido ya existe";	
			}
			else if(EjecutarIUD($CadSql,$link))
			{
				$mensaje="Partido añadido exitosamente";
			}
			else
			{
				$mensaje="Error al añadir partido";
			}
		}
		?>
		<br><br>
		<div class="row">
			<div class="col-sm-3"></div>
			<div class="col-sm-6">
				<div class="panel panel-primary">
					<div class="panel-heading"> <?php echo $mensaje;?> </div>
				</div>
			</div>
			<div class="col-sm-3"></div>
		</div>

	</div>
</div>
<div class="row">
	<div class="col-sm-12" id="pie">
		<div class="clearfix"></div>
    <footer id="footer">
        <div class="wrap">

            <div id="info">
                <h5>Desarrollado con</h5>
                <p>
                    <img src="img/html5.png" alt="Creado con HTML y CSS">
                    <img src="img/php.png" alt="Programado con PHP" height="100px">
                </p>
            </div>
            <div>
                <h5>AUTOR</h5>
                <p>&copy; Daniel Ruiz</p>
                <p>Estudiante de Ingeniería Informática</p>
                <p>Contacto: d.ruiz03@ufromail.cl</p>
                <img src="img/logo_ufro.png" alt="Universidad de la Frontera" height="150px">
            </div>

            

        </div>
    </footer>
	</div>
</div>
</body>
</html>