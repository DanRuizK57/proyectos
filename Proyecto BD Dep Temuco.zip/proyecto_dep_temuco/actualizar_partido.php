<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Actualizar Partido</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="row">
		<div class="col-sm-12 text-center" id="encabezado">
			<?php 
			include "php/encabezado.php";
			?>
		</div>
	</div>
	<div class="row">
		</div>
		<div class="col-sm-12 text-center" id="contenido">
		<br>
		<?php 
		include "php/menu.php";
		if(isset($_POST["txtNroPartido"]))
		{	
			include "php/conexionBD.php";
			include "php/validaciones.php";
			$link=AbrirConexion();
			$codCampeonato=$_POST["cboCampeonato"];
			$nroPartido=$_POST["txtNroPartido"];
			$fechaPartido=$_POST["dtFechaPartido"];
			$codEstadio=$_POST["cboEstadio"];
			$codEquipoLocal=$_POST["cboEquipoLocal"];
			$codEquipoVisita=$_POST["cboEquipoVisita"];
			$golesLocal=$_POST["txtGolesLocal"];
			$golesVisita=$_POST["txtGolesVisita"];

			if(!ExistePartido($nroPartido))
			{
				$mensaje="Partido no encontrado, imposible modificar datos.";	
			}
			else if (isset($_POST["cmdModificar"])) 
			{
				$CadSql="update partido set cod_campeonato='".$codCampeonato."',";
				$CadSql.="fecha_partido='".$fechaPartido."',";
				$CadSql.="cod_estadio='".$codEstadio."',";
				$CadSql.="cod_equipo_local='".$codEquipoLocal."',";
				$CadSql.="cod_equipo_visita='".$codEquipoVisita."',";
				$CadSql.="goles_local='".$golesLocal."',";
				$CadSql.="goles_visita='".$golesVisita."' ";
				$CadSql.=" where nro_partido='".$nroPartido."';";
				//echo $CadSql;
				if(EjecutarIUD($CadSql,$link))
				{
					$mensaje="Partido modificado exitosamente";
				}
				else
				{
					$mensaje="Error al modificar partido";
				}
			}
			else if (isset($_POST["cmdEliminar"])) 
			{
				$CadSql="delete from partido where nro_partido='".$nroPartido."';";
				if(EjecutarIUD($CadSql,$link))
				{
					$mensaje="Partido eliminado exitosamente";
				}
				else
				{
					$mensaje="Error al eliminar cliente";
				}
			}
		}
		?>
		<br><br>
		<div class="row">
			<div class="col-sm-3"></div>
			<div class="col-sm-6">
				<div class="panel panel-primary">
					<div class="panel-heading"> <?php echo $mensaje;?> </div>
				</div>
			</div>
			<div class="col-sm-3"></div>
		</div>

	</div>
</div>
<div class="row">
	<div class="col-sm-12" id="pie">
		<div class="clearfix"></div>
    <footer id="footer">
        <div class="wrap">

            <div id="info">
                <h5>Desarrollado con</h5>
                <p>
                    <img src="img/html5.png" alt="Creado con HTML y CSS">
                    <img src="img/php.png" alt="Programado con PHP" height="100px">
                </p>
            </div>
            <div>
                <h5>AUTOR</h5>
                <p>&copy; Daniel Ruiz</p>
                <p>Estudiante de Ingeniería Informática</p>
                <p>Contacto: d.ruiz03@ufromail.cl</p>
                <img src="img/logo_ufro.png" alt="Universidad de la Frontera" height="150px">
            </div>

            

        </div>
    </footer>
	</div>
</div>
</body>
</html>