<?php date_default_timezone_set('America/Santiago'); ?>
<h5>&nbsp;&nbsp;&nbsp;&nbsp;Email: <em>d.ruiz03@gmail.com</em></h5>
<h5>&nbsp;&nbsp;&nbsp;&nbsp;Fecha:                 <?php echo date("d-m-y");?> &nbsp;&nbsp;&nbsp;&nbsp;
Hora: <?php echo date("H:i:s");?>
</h5>