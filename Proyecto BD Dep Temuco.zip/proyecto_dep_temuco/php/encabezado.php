<div class="row">
	<div class="col-sm-2">
		<img src="img/DeportesTemuco.png" alt="logo ufro" height="150px">
	</div>
	<div class="col-sm-10">
			<h1 float="left">REGISTRO PARTIDOS DEP. TEMUCO</h1>
                <h2>2014 - 2021</h2>
	</div>
</div>

