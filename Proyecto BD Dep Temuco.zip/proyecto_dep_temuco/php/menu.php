<a href="index.php" class="btn btn-primary">Inicio</a>
<a href="crear_partido.php" class="btn btn-primary">Añadir Partido</a>
<a href="buscar_partido.php" class="btn btn-primary">Buscar Partido</a>
<a href="listado_partidos.php" class="btn btn-primary">Listado Partidos</a>
<a href="listado_temporadas.php" class="btn btn-primary">Listado Temporadas</a>
<a href="listado_campeonatos.php" class="btn btn-primary">Listado Campeonatos</a>
<a href="listado_equipos.php" class="btn btn-primary">Listado Equipos</a>
<a href="listado_estadios.php" class="btn btn-primary">Listado Estadios</a>
<a href="listado_jugadores.php" class="btn btn-primary">Listado Jugadores</a>
<a href="listado_dt.php" class="btn btn-primary">Listado DT</a>
<a href="listado_ciudades.php" class="btn btn-primary">Listado Ciudades</a>
<a href="listado_paises.php" class="btn btn-primary">Listado Paises</a>