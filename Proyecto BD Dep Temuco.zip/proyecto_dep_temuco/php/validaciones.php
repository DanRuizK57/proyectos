<?php 
function ExistePartido($nroPartido)
{
	//include "conexionBd.php";
	$link=AbrirConexion();
	$CadSql="Select a.fecha_partido from partido a where a.nro_partido='".$nroPartido."';";
	//echo $CadSql;
	$resultado=EjecutarConsulta($CadSql,$link);
	$existe=false;
	if($resultado->num_rows>0)
	{
		$existe=true;
	}
	return($existe);
}

?>