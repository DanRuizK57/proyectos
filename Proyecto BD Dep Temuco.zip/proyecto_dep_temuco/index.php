<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Proyecto Deportes Temuco</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="row">
		<div class="col-sm-12 text-center" id="encabezado">
			<?php 
			include "php/encabezado.php";
			?>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12 text-center" id="contenido">
		<br><br><br><br>
		<?php 
		include "php/menu.php";
		include "php/conexionBD.php";
		$link=AbrirConexion();
		CerrarConexion($link);
		?>
		<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	</div>
</div>
<div class="row">
	<div class="col-sm-12" id="pie">
		<div class="clearfix"></div>
    <footer id="footer">
        <div class="wrap">

            <div id="info">
                <h5>Desarrollado con</h5>
                <p>
                    <img src="img/html5.png" alt="Creado con HTML y CSS">
                    <img src="img/php.png" alt="Programado con PHP" height="100px">
                </p>
            </div>
            <div>
                <h5>AUTOR</h5>
                <p>&copy; Daniel Ruiz</p>
                <p>Estudiante de Ingeniería Informática</p>
                <p>Contacto: d.ruiz03@ufromail.cl</p>
                <img src="img/logo_ufro.png" alt="Universidad de la Frontera" height="150px">
            </div>

            

        </div>
    </footer>
	</div>
</div>
</body>
</html>