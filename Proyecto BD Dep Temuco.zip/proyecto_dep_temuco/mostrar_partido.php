<?php 
include "php/conexionBD.php";
include "php/validaciones.php";
$nroPartido=$_POST["txtNroPartido"];
if(!ExistePartido($nroPartido))
{
	header("location: buscar_partido.php?error=si");
}

$link=AbrirConexion();
$CadSql="Select a.cod_campeonato,a.nombre_campeonato from campeonato a;";
$campeonatos=EjecutarConsulta($CadSql,$link);

$CadSql="Select b.cod_estadio,b.nombre_estadio from estadio b;";
$estadios=EjecutarConsulta($CadSql,$link);

$CadSql="Select c.cod_equipo 'cod_equipo_local',c.nombre_equipo 'nombre_equipo_local' from equipo c;";
$equiposLocal=EjecutarConsulta($CadSql,$link);

$CadSql="Select d.cod_equipo 'cod_equipo_visita',d.nombre_equipo 'nombre_equipo_visita' from equipo d;";
$equiposVisita=EjecutarConsulta($CadSql,$link);

$CadSql="Select a.cod_campeonato,a.nro_partido,a.fecha_partido,a.cod_estadio,a.cod_equipo_local,";
$CadSql.="a.cod_equipo_visita,a.goles_local,a.goles_visita,b.cod_campeonato,b.nombre_campeonato,c.cod_estadio, ";
$CadSql.="c.nombre_estadio,d.nombre_equipo 'nombre_equipo_local',e.nombre_equipo 'nombre_equipo_visita' ";
$CadSql.=" from partido a,campeonato b,estadio c,equipo d,equipo e ";
$CadSql.=" where a.cod_campeonato=b.cod_campeonato and a.cod_estadio=c.cod_estadio and a.cod_equipo_local=d.cod_equipo";
$CadSql.=" and a.cod_equipo_visita=e.cod_equipo and a.nro_partido='".$nroPartido."';";
//echo $CadSql;
$resultado=EjecutarConsulta($CadSql,$link);
if($fila=$resultado->fetch_array())
{
	$codCampeonato=$fila["cod_campeonato"];
	$fechaPartido=$fila["fecha_partido"];
	$codEstadio=$fila["cod_estadio"];
	$codEquipoLocal=$fila["cod_equipo_local"];
	$codEquipoVisita=$fila["cod_equipo_visita"];
	$golesLocal=$fila["goles_local"];
	$golesVisita=$fila["goles_visita"];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Partido</title>
	

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="row">
		<div class="col-sm-12 text-center" id="encabezado">
			<?php 
			include "php/encabezado.php";
			?>
		</div>
	</div>
	<div class="row">
		</div>
		<div class="col-sm-12 text-center" id="contenido">
			<form action="actualizar_partido.php" method="POST">
				<br>
				<?php 
				include "php/menu.php";
				
			//CerrarConexion($link);
				?>
				<br><br>
				<div class="col-sm-3"></div>
				<div class="col-sm-6">
					<div class="panel panel-primary">
						<div class="panel-heading">Revisi&oacute;n Partido</div>
						<div class="panel-body text-left">
      				<div class="col-sm-3">N&uacute;mero Partido</div>
      				<div class="col-sm-9">
      					<input type="search" name="txtNroPartido" id="txtNroPartido" placeholder="Ingrese n° partido" maxlength="6" minlength="1" required="required" size="45" value="<?php echo $nroPartido;?>">
      				</div>
      			</div>
      			<div class="panel-body text-left">
      				<div class="col-sm-3">Campeonato</div>
      				<div class="col-sm-9">
      					<select name="cboCampeonato" id="cboCampeonato">
      						<option value="">Escoja campeonato</option>
      						<?php 
      							while($fila=$campeonatos->fetch_array())
      							{
      								$selected="";
      								if ($codCampeonato==$fila["cod_campeonato"]) 
      								{
      									$selected='selected="selected"';
      								}
      								echo '<option value="'.$fila["cod_campeonato"].'" '.$selected.'>';
      								echo $fila["nombre_campeonato"].'</option>';
      							}
      							//CerrarConexion($link);
      						 ?>
      					</select>
      				</div>
      			</div>
      			<div class="panel-body text-left">
      				<div class="col-sm-3">Fecha Partido</div>
      				<div class="col-sm-9">
      					<input type="date" name="dtFechaPartido" id="dtFechaPartido" placeholder="Escoje fecha" required="required" size="45" value="<?php echo $fechaPartido;?>">
      				</div>
      			</div>
      			<div class="panel-body text-left">
      				<div class="col-sm-3">Estadio</div>
      				<div class="col-sm-9">
      					<select name="cboEstadio" id="cboEstadio">
      						<option value="">Escoja estadio</option>
      						<?php 
      							while($fila=$estadios->fetch_array())
      							{
      								$selected="";
      								if ($codEstadio==$fila["cod_estadio"]) 
      								{
      									$selected='selected="selected"';
      								}
      								echo '<option value="'.$fila["cod_estadio"].'" '.$selected.'>';
      								echo $fila["nombre_estadio"].'</option>';
      							}
      							//CerrarConexion($link);
      						 ?>
      					</select>
      				</div>
      			</div>
      			<div class="panel-body text-left">
      				<div class="col-sm-3">Equipo Local</div>
					<div class="col-sm-9"> 
						<select name="cboEquipoLocal" id="cboEquipoLocal">
							<option value="">Escoja equipo</option>
							<?php 
							while ($fila=$equiposLocal->fetch_array()) 
							{
								$selected="";
      								if ($codEquipoLocal==$fila["cod_equipo_local"]) 
      								{
      									$selected='selected="selected"';
      								}
								echo '<option value="'.$fila["cod_equipo_local"].'" '.$selected.'>';
								echo $fila["nombre_equipo_local"].'</option>';
							}
							?>
						</select>
					</div>
				</div>
				<div class="panel-body text-left">
      				<div class="col-sm-3">Equipo Visitante</div>
					<div class="col-sm-9"> 
						<select name="cboEquipoVisita" id="cboEquipoVisita">
							<option value="">Escoja equipo</option>
							<?php 
							while ($fila=$equiposVisita->fetch_array()) 
							{
								$selected="";
      								if ($codEquipoVisita==$fila["cod_equipo_visita"]) 
      								{
      									$selected='selected="selected"';
      								}
								echo '<option value="'.$fila["cod_equipo_visita"].'" '.$selected.'>';
								echo $fila["nombre_equipo_visita"].'</option>';
								}
							?>
						</select>
					</div>
				</div>
      			<div class="panel-body text-left">
      				<div class="col-sm-3">Goles Local</div>
      				<div class="col-sm-9">
      					<input type="search" name="txtGolesLocal" id="txtGolesLocal" placeholder="Ingrese n° goles" maxlength="2" minlength="1" required="required" size="45" value="<?php echo $golesLocal;?>">
      				</div>
      			</div>
      			<div class="panel-body text-left">
      				<div class="col-sm-3">Goles Visita</div>
      				<div class="col-sm-9">
      					<input type="search" name="txtGolesVisita" id="txtGolesVisita" placeholder="Ingrese n° goles" maxlength="2" minlength="1" required="required" size="45" value="<?php echo $golesVisita;?>">
      				</div>
      			</div>
						<div class="panel-body text-center">
							<div class="col-sm-4">
								<input type="submit" name="cmdModificar" id="cmdModificar" value="Modificar Partido" class="btn btn-primary">
							</div>
							<div class="col-sm-4">
								<input type="submit" name="cmdEliminar" id="cmdEliminar" value="Eliminar Partido" class="btn btn-danger">
							</div>
							<div class="col-sm-4"> 
								<input type="reset" name="cmdLimpiar" id="cmdLimpiar" value="Restablecer" class="btn btn-success">
							</div>
						</div>
				</div>
					</div>
				</div>
				<div class="col-sm-3"></div>
			</form>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12" id="pie">
			<div class="clearfix"></div>
    <footer id="footer">
        <div class="wrap">

            <div id="info">
                <h5>Desarrollado con</h5>
                <p>
                    <img src="img/html5.png" alt="Creado con HTML y CSS">
                    <img src="img/php.png" alt="Programado con PHP" height="100px">
                </p>
            </div>
            <div>
                <h5>AUTOR</h5>
                <p>&copy; Daniel Ruiz</p>
                <p>Estudiante de Ingeniería Informática</p>
                <p>Contacto: d.ruiz03@ufromail.cl</p>
                <img src="img/logo_ufro.png" alt="Universidad de la Frontera" height="150px">
            </div>

            

        </div>
    </footer>
		</div>
	</div>
</body>
</html>