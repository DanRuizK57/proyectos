<?php 
include "php/conexionBD.php";
$link=AbrirConexion();
$codPais=$_POST["pais"];

$CadSql="Select a.cod_ciudad,a.des_ciudad from ciudad a where a.cod_pais='".$codPais."';";
$resultado=EjecutarConsulta($CadSql,$link);
$html='<option value="">Escoja ciudad</option>';
while ($fila=$resultado->fetch_array()) {
	$html.='<option value="'.$fila["cod_ciudad"].'">'.$fila["des_ciudad"].'</option>';
}
echo $html;
?>