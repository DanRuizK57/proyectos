<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Listado de Estadios</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="row">
		<div class="col-sm-12 text-center" id="encabezado">
			<?php 
			include "php/encabezado.php";
			?>
		</div>
	</div>
	<div class="row">
		</div>
		<div class="col-sm-12 text-center" id="contenido">
		<br>
		<?php 
		include "php/menu.php";
		include "php/conexionBD.php";
		$link=AbrirConexion();
		

		$CadSql="Select a.cod_estadio,a.nombre_estadio,a.direccion,b.cod_ciudad,b.des_ciudad ";
		$CadSql.=" from estadio a,ciudad b where a.cod_ciudad=b.cod_ciudad;";
		$resultado=EjecutarConsulta($CadSql,$link);
		?>
		<table class="listado" border="1">
			<br><br>
			<tr>
					<th>C&oacute;digo Estadio</th>
					<th>Nombre Estadio</th>
					<th>Nombre Ciudad</th>
					<th>Direcci&oacute;n</th>
				</tr>

				<?php
				while($fila=$resultado->fetch_array())
				{
					echo "<tr><td>".$fila["cod_estadio"]."</td>";
					echo "<td>".$fila["nombre_estadio"]."</td>";
					echo "<td>".$fila["des_ciudad"]."</td>";
					echo "<td>".$fila["direccion"]."</td></tr>";
				}
				?>
				<tr>
					<td>Total Estadios</td>
					<td>
						<?php echo $resultado->num_rows;?>	
					</td>
				</tr>
		</table>
		<?php
		CerrarConexion($link);
		?>
		<br><br>
	</div>
</div>
<div class="row">
	<div class="col-sm-12" id="pie">
		<div class="clearfix"></div>
    <footer id="footer">
        <div class="wrap">

            <div id="info">
                <h5>Desarrollado con</h5>
                <p>
                    <img src="img/html5.png" alt="Creado con HTML y CSS">
                    <img src="img/php.png" alt="Programado con PHP" height="100px">
                </p>
            </div>
            <div>
                <h5>AUTOR</h5>
                <p>&copy; Daniel Ruiz</p>
                <p>Estudiante de Ingeniería Informática</p>
                <p>Contacto: d.ruiz03@ufromail.cl</p>
                <img src="img/logo_ufro.png" alt="Universidad de la Frontera" height="150px">
            </div>

            

        </div>
    </footer>
	</div>
</div>
</body>
</html>