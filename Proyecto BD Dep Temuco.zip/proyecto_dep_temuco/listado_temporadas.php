<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Listado de Temporadas</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="row">
		<div class="col-sm-12 text-center" id="encabezado">
			<?php 
			include "php/encabezado.php";
			?>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-10 text-center" id="contenido">
		<br>
		<?php 
		include "php/menu.php";
		include "php/conexionBD.php";
		$link=AbrirConexion();
		

		$CadSql="Select a.cod_campeonato,a.cod_equipo,a.posicion_campeonato,a.puntos_obtenidos,a.partidos_jugados,a.partidos_ganados,a.partidos_empatados,a.partidos_perdidos,a.diferencia_de_goles,a.goles_a_favor,a.goles_en_contra,b.cod_campeonato,b.nombre_campeonato,c.cod_equipo,c.nombre_equipo ";
		$CadSql.=" from equipos_campeonato a,campeonato b,equipo c where a.cod_campeonato=b.cod_campeonato and a.cod_equipo=c.cod_equipo;";
		$resultado=EjecutarConsulta($CadSql,$link);
		?>
		<table class="listado" border="1">
			<br>
			<tr>
				<th>C&oacute;digo Campeonato</th>
				<th>Nombre Campeonato</th>
				<th>Equipo</th>
				<th>Posici&oacute;n Tabla</th>
				<th>Puntos Obtenidos</th>
				<th>Partidos Jugados</th>
				<th>Partidos Ganados</th>
				<th>Partidos Empatados</th>
				<th>Partidos Perdidos</th>
				<th>Diferencia de Goles</th>
				<th>Goles a Favor</th>
				<th>Goles en Contra</th>
			</tr>
			<br>
			<?php 
			$total=0;
			while ($fila=$resultado->fetch_array()) {
				echo "<tr><td>".$fila["cod_campeonato"]."</td>";
				echo "<td>".$fila["nombre_campeonato"]."</td>";
				echo "<td>".$fila["nombre_equipo"]."</td>";
				echo "<td>".$fila["posicion_campeonato"]."</td>";
				echo "<td>".$fila["puntos_obtenidos"]."</td>";
				echo "<td>".$fila["partidos_jugados"]."</td>";
				echo "<td>".$fila["partidos_ganados"]."</td>";
				echo "<td>".$fila["partidos_empatados"]."</td>";
				echo "<td>".$fila["partidos_perdidos"]."</td>";
				echo "<td>".$fila["diferencia_de_goles"]."</td>";
				echo "<td>".$fila["goles_a_favor"]."</td>";
				echo "<td>".$fila["goles_en_contra"]."</td></tr>";
			}
			?>
			<tr>
				<td>Total Temporadas</td>
				<td><?php echo $resultado->num_rows;?></td>		
			</tr>
		</table>
		<?php
		CerrarConexion($link);
		?>
		<br><br>
	</div>
</div>
<div class="row">
	<div class="col-sm-12" id="pie">
		<div class="clearfix"></div>
    <footer id="footer">
        <div class="wrap">

            <div id="info">
                <h5>Desarrollado con</h5>
                <p>
                    <img src="img/html5.png" alt="Creado con HTML y CSS">
                    <img src="img/php.png" alt="Programado con PHP" height="100px">
                </p>
            </div>
            <div>
                <h5>AUTOR</h5>
                <p>&copy; Daniel Ruiz</p>
                <p>Estudiante de Ingeniería Informática</p>
                <p>Contacto: d.ruiz03@ufromail.cl</p>
                <img src="img/logo_ufro.png" alt="Universidad de la Frontera" height="150px">
            </div>

            

        </div>
    </footer>
	</div>
</div>
</body>
</html>